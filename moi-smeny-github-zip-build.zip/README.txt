# Мои смены — загрузка в GitHub

В корень репозитория GitHub загрузи оба файла из этого комплекта:
- `moi_smeny_cloud_build.zip`
- `build-apk.yml`

Файл `build-apk.yml` нужно положить по пути `.github/workflows/build-apk.yml` (создай папки `.github/workflows`, если их нет). Не клади YAML просто в корень репозитория.

Затем открой GitHub → Actions → Build Moi Smeny APK → Run workflow.
После успешной сборки скачай артефакт `Moi-Smeny-APK`. Внутри будет `app-debug.apk`.
